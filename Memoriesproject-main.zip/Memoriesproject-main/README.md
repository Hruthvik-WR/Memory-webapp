# Memoriesproject

This project is all about adding your memories of your special days that you spent.

the link to the project is : https://saiprojectmern.netlify.app/
